﻿using Exercicio;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

internal class ProfDE : Professor
{
    public ProfDE(string nome, int matricula, int cargaHoraria)
        : base(nome, matricula, cargaHoraria)
    {
    }

    public override void CalcularBeneficio()
    {
        
        Beneficio = 2000 + (CargaHoraria * 10);
    }
}