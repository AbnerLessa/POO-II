﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exercicio
{
    internal class ProfHorista : Professor
    {
        private double valorHora;

        public ProfHorista(string nome, int matricula, int cargaHoraria, double valorHora)
            : base(nome, matricula, cargaHoraria)
        {
            this.valorHora = valorHora;
        }

        public override void CalcularBeneficio()
        {
            Beneficio = CargaHoraria * valorHora;
        }
    }
}