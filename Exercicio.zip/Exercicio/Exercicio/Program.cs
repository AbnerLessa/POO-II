﻿using Exercicio;
using System;

class Program
{
    static void Main()
    {
       
        Professor profDE = new ProfDE("Abner", 123, 40);
        profDE.CalcularBeneficio();
        Console.WriteLine(profDE);


        Professor profHorista = new ProfHorista("João Bahia", 456, 1, 1);
        profHorista.CalcularBeneficio();
        Console.WriteLine(profHorista);
    }
}