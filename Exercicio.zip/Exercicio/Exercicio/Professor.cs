﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exercicio
{
    internal abstract class Professor
    {
        private string nome { get; set; }
        private int matricula { get; set; }
        private int cargaHoraria { get; set; }
        private double beneficio { get; set; }


        public Professor(string nome, int matricula, int cargaHoraria)
        {
            this.nome = nome;
            this.matricula = matricula;
            this.cargaHoraria = cargaHoraria;
        }


        public string Nome
        {
            get { return nome; }
            set { nome = value; }
        }

        public int Matricula
        {
            get { return matricula; }
            set { matricula = value; }
        }

        public int CargaHoraria
        {
            get { return cargaHoraria; }
            set { cargaHoraria = value; }
        }

        public double Beneficio
        {
            get { return beneficio; }
            protected set { beneficio = value; }
        }


        public abstract void CalcularBeneficio();

        public override string ToString()
        {
            return $"Nome: {nome}, Matrícula: {matricula}, Carga Horária: {cargaHoraria}, Benefício: {beneficio:C}";
        }
    }
}